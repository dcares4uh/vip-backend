from django.contrib import admin
from .models import RazorpayPayment
# Register your models here.

admin.site.register(RazorpayPayment)
